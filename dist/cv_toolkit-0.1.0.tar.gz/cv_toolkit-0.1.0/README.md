



# TO-DO:


Metrics:

[ ] LPIPS

[ ] NIQE

[ ] BRISQUE

[ ] [Sharpness Estimation for Document and Scene Images](https://github.com/umang-singhal/pydom)


Losses:

[ ] TVLoss

[ ] FourierLoss

[ ] 